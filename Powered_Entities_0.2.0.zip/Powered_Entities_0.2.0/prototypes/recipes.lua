data:extend ({

{
    type = "recipe",
    name = "power-pad",
    enabled = false,
    ingredients =
    {
      {"electronic-circuit", 2},
      {"copper-cable", 2},
      {"iron-plate", 1}
    },
    result = "power-pad"
}
})