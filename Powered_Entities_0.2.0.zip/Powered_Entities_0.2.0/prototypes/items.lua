data:extend ({

{
    type = "item",
    name = "power-pad",
    icon = "__Powered_Entities__/graphics/power_pad_off.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy-pipe-distribution",
    order = "a[energy]-e[power-pad]",
    place_result = "power-pad",
    stack_size = 50
}
})